package com.jsp.servlet_simple_crud_operartion.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import com.jsp.servlet_simple_crud_operartion.dao.UserDao;
import com.jsp.servlet_simple_crud_operartion.entity.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class InsertUserController implements Servlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		
		UserDao dao = new UserDao();
		
		PrintWriter printWriter=res.getWriter();
		
		res.setContentType("text/html");
		
		int id=Integer.parseInt(req.getParameter("userid"));
		
		String name=req.getParameter("username");
		String email=req.getParameter("useremail");
		String password=req.getParameter("userpassword");
		LocalDate dob=LocalDate.parse(req.getParameter("userdob"));
		String gender=req.getParameter("gender");
		
		User user=new User(id, name, email, password, dob, gender);
		
		User user2=dao.saveUserDao(user);
		
		if(user2!=null) {
			req.setAttribute("msg", "data registered");
			//printWriter.write("<html><body><h5 style='color:green;'>Data registered!!!</h5></body></html>");
			RequestDispatcher dispatcher=req.getRequestDispatcher("login.jsp");
			dispatcher.include(req, res);
		}else {
			req.setAttribute("msg", "data not registered");
			//printWriter.write("<html><body><h5 style='color:red;'>Not Registered</h5></body></html>");
			RequestDispatcher dispatcher=req.getRequestDispatcher("register.jsp");
			dispatcher.include(req, res);
		}	
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

}
