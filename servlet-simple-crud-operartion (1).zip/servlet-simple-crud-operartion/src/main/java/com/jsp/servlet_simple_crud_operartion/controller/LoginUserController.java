package com.jsp.servlet_simple_crud_operartion.controller;

import java.io.IOException;

import com.jsp.servlet_simple_crud_operartion.dao.UserDao;
import com.jsp.servlet_simple_crud_operartion.entity.User;

import jakarta.servlet.GenericServlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class LoginUserController extends GenericServlet {
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		UserDao dao = new UserDao();
		String email = req.getParameter("useremail");
		String password = req.getParameter("userpassword");
		User user=dao.getUserByEmailDao(email);
		if(user!=null) {
			if(user.getPassword().equals(password)) {
				req.getRequestDispatcher("display.jsp").forward(req, res);
			}else {
				req.setAttribute("msg", "password is wrong");
				req.getRequestDispatcher("login.jsp").forward(req, res);
			}
		}else {
			req.setAttribute("msg", "email is wrong");
			req.getRequestDispatcher("login.jsp").forward(req, res);
		}
		
	}

}
